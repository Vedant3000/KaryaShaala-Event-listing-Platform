// var express = require("express")
// var bodyParser = require("body-parser")
// var mongoose = require("mongoose")

// const app = express()

// app.use(bodyParser.json())
// app.use(express.static('public'))
// app.use(bodyParser.urlencoded({
//     extended:true
// }))

// mongoose.connect('mongodb://localhost:27017/mydb',{
//     useNewUrlParser: true,
//     useUnifiedTopology: true
// });

// var db = mongoose.connection;

// db.on('error',()=>console.log("Error in Connecting to Database"));
// db.once('open',()=>console.log("Connected to Database"))

// app.post("/sign_up",(req,res)=>{
//     var event_name = req.body.a1;
//     var spokesperson = req.body.a2;
//     var venue = req.body.a3;         
//     var date= req.body.a4;
//    var name_of_org = req.body.a5;
//     var description = req.body.a6;

//     var data = {
//         "event_name": event_name,
//         "spokesperson" : spokesperson,
//         "venue": venue,
//         "date" : date,
//         "name_of_org": name_of_org,
//         "description": description
//     }

//     db.collection('users').insertOne(data,(err,collection)=>{
//         if(err){
//             throw err;
//         }
//         console.log("Record Inserted Successfully");
//     });

//     return res.redirect('signup_success.html')

// })




// app.get("/",(req,res)=>{
//     res.set({
//         "Allow-access-Allow-Origin": '*'
//     })
//     return res.redirect('index.html');
// }).listen(3000);


// console.log("Listening on PORT 3000");


// const express = require("express");
// const bodyParser = require("body-parser");
// const cors = require('cors');
// const mongoose = require("mongoose")


// const app = express();


// const PORT = process.env.PORT || 3000
// app.use(cors());

// app.use(function(req, res, next) {
//    res.header("Access-Control-Allow-Origin", "*");
//    res.header('Access-Control-Allow-Methods', 'DELETE, PUT, GET, POST');
//    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
//    next();
// });

// app.set('view engine', 'ejs');

// // app.use(bodyParser.urlencoded({extended: true}));
// app.use(express.static("public"));

// app.use(express.json());
// mongoose.connect('mongodb://localhost:27017/mydb',{
//     useNewUrlParser: true,
//     useUnifiedTopology: true
// });

// var db = mongoose.connection;

// db.on('error',()=>console.log("Error in Connecting to Database"));
// db.once('open',()=>console.log("Connected to Database"))

// app.get('/',function(req,res){
//     res.json({api:'working fine! good to go.'})
// })

// app.get('/API/scrape' ,function(req,res){
//     res.json("hello ")})

// app.post('/API/scrape', function(req,res){
    
    
// })

// app.post("/sign_up",(req,res)=>{
//     var event_name = req.body.a1;
//     var spokesperson = req.body.a2;
//     var venue = req.body.a3;         
//     var date= req.body.a4;
//    var name_of_org = req.body.a5;
//     var description = req.body.a6;

//     var data = {
//         "event_name": event_name,
//         "spokesperson" : spokesperson,
//         "venue": venue,
//         "date" : date,
//         "name_of_org": name_of_org,
//         "description": description
//     }
// })


// app.listen(PORT, () => {
//     console.log(`Server started on PORT ${PORT}`)
//   })




var express = require("express")
var bodyParser = require("body-parser")          
var mongoose = require("mongoose")

const app = express()

app.use(bodyParser.json())
app.use(express.static('public'))          
app.use(bodyParser.urlencoded({
    extended:true
}));

mongoose.connect('mongodb://localhost:27017/mydb',{
    useNewUrlParser: true,
    useUnifiedTopology: true
})

var db = mongoose.connection;

db.on('error',()=>console.log("Error in Connecting to Database"));
db.once('open',()=>console.log("Connected to Database"))

app.post("/sign_up",(req,res)=>{
    var event_name = req.body.a1;
    var spokesperson = req.body.a2;
    var venue = req.body.a3;         
    var date= req.body.a4;
    var name_of_org = req.body.a5;
    var description = req.body.a6;

    var data = {
        "event_name": event_name,
        "spokesperson" : spokesperson,
        "venue": venue,
        "date" : date,
        "name_of_org": name_of_org,
        "description": description
    }

    db.collection('movies').insertOne(data,(err,collection)=>{
        if(err){
            throw err;
        }
        console.log("Record Inserted Successfully");
    });

    return res.redirect('signup_success.html')

})


app.get("/",(req,res)=>{
    res.set({
        "Allow-access-Allow-Origin": '*'
    })
    return res.redirect('index.html');
}).listen(3000);


console.log("Listening on PORT 3000");
